Boccia — Windows x64

1. ZIP 전체를 쓰기 가능한 폴더에 압축 해제하세요.
2. boccia_calibration.exe를 실행하세요. DLL과 xml, userset 폴더를 함께 유지하세요.
3. 실제 카메라 연결에는 해당 카메라용 MV Viewer 드라이버가 설치되어 있어야 합니다.
   카메라 없이 녹화 폴더를 재생할 수도 있습니다.

설정·보정값·레이아웃: 이 폴더의 data/ 아래에 생성됩니다.
녹화 기본 위치: data/recordings/
도구 → Recording / Playback: 기본 Lossless / 30 FPS. Record FPS 또는 Original FPS로 변경합니다.
도구 → Ball Detection: 녹화와 실시간 영상에 같은 검출을 적용합니다.
기존 data/settings.json과 data/ui-layout.json이 있다면 종료 상태에서 data/로 옮길 수 있습니다.

사용법: CALIBRATION.md
빌드 정보: build-info.json
외부 라이브러리 고지: licenses/

이 패키지에는 개인 카메라 보정값, 녹화 영상, 계정 정보가 포함되지 않습니다.
